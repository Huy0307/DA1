#ifndef DS1307_H
#define DS1307_H
#include <RTClib.h>
#include <Wire.h>
void ds1307setup();
void checkTime();
#endif